#include <bits/stdc++.h>
using namespace std;
vector<int>zeroend(vector<int>v,int siz){
    int j = -1;
    for (int i=0;i<siz;i++){
        if (v[i] == 0){
            
        }
    }
}
int main()
{
    vector<int>v = {1,4,5,6,7,0,54,44,0,87,0,98,0,96,112,0,0,0,45};

    int siz = v.size();
    auto start = std::chrono::high_resolution_clock::now();
    vector<int>arr=zeroend(v,siz);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;

    double duration_ms = duration.count() * 1000;
    std::cout << "\nExecution time: " << duration_ms << " milliseconds" << std::endl;

    for (auto &it : arr){
        cout<<it<<" ";
    }
    return 0;
}