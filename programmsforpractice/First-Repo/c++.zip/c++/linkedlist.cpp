#include <bits/stdc++.h>
using namespace std;
class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = nullptr;
    }
};

class LinkedList {
private:
    Node* head;
public:
    LinkedList() {
        head = nullptr;
    }

    void insertAtBeginning(int data) {
        Node* newNode = new Node(data);
        newNode->next = head;
        head = newNode;
    }

    void insertAtEnd(int data) {
        Node* newNode = new Node(data);
        if (head == nullptr) {
            head = newNode;
            return;
        }
        Node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }

    void insertAtPosition(int data, int position) {
        if (position < 0) {
            cout << "Invalid position" << endl;
            return;
        }
        if (position == 0) {
            insertAtBeginning(data);
            return;
        }
        Node* newNode = new Node(data);
        Node* current = head;
        int count = 0;
        while (count < position - 1 && current != nullptr) {
            current = current->next;
            count++;
        }
        if (current == nullptr) {
            cout << "Position out of range" << endl;
            return;
        }
        newNode->next = current->next;
        current->next = newNode;
    }

    void deleteAtPosition(int position) {
        if (head == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        if (position == 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Node* current = head;
        int count = 0;
        while (count < position - 1 && current->next != nullptr) {
            current = current->next;
            count++;
        }
        if (current->next == nullptr) {
            cout << "Position out of range" << endl;
            return;
        }
        Node* temp = current->next;
        current->next = current->next->next;
        delete temp;
    }

    void deleteAtFirst() {
        deleteAtPosition(0);
    }

    void deleteAtLast() {
        if (head == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        if (head->next == nullptr) {
            delete head;
            head = nullptr;
            return;
        }
        Node* current = head;
        while (current->next->next != nullptr) {
            current = current->next;
        }
        delete current->next;
        current->next = nullptr;
    }

    void display() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " -> ";
            current = current->next;
        }
        if (head == nullptr) {

        cout << "\nNot Avialable...."<< endl;
        }
    }

    int size() {
        int count = 0;
        Node* current = head;
        while (current != nullptr) {
            count++;
            current = current->next;
        }
        return count;
    }

    void reverse() {
        Node* prev = nullptr;
        Node* current = head;
        while (current != nullptr) {
            Node* nextNode = current->next;
            current->next = prev;
            prev = current;
            current = nextNode;
        }
        head = prev;
    }
};

int main() {
    LinkedList linkedList;

    while (true) {
        cout << "\nMenu:" << endl;
        cout << "1. Insert at the beginning" << endl;
        cout << "2. Insert at the end" << endl;
        cout << "3. Insert at a given position" << endl;
        cout << "4. Delete at a given position" << endl;
        cout << "5. Delete at the first" << endl;
        cout << "6. Delete at the last" << endl;
        cout << "7. Display" << endl;
        cout << "8. Size of the linked list" << endl;
        cout << "9. Reverse the linked list" << endl;
        cout << "10. Exit" << endl;

        int choice;
        cin >> choice;

        int data, position;

        switch (choice) {
            case 1:
                cout << "Enter data: ";
                cin >> data;
                linkedList.insertAtBeginning(data);
                break;
            case 2:
                cout << "Enter data: ";
                cin >> data;
                linkedList.insertAtEnd(data);
                break;
            case 3:
                cout << "Enter data: ";
                cin >> data;
                cout << "Enter position: ";
                cin >> position;
                linkedList.insertAtPosition(data, position);
                break;
            case 4:
                cout << "Enter position to delete: ";
                cin >> position;
                linkedList.deleteAtPosition(position);
                break;
            case 5:
                linkedList.deleteAtFirst();
                break;
            case 6:
                linkedList.deleteAtLast();
                break;
            case 7:
                linkedList.display();
                break;
            case 8:
                cout << "Size of the linked list: " << linkedList.size() << endl;
                break;
            case 9:
                linkedList.reverse();
                cout << "Linked list reversed" << endl;
                break;
            case 10:
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}

