#include<bits/stdc++.h>
using namespace std;

void bubbleSort(int arr[],int n){

}
int main(){
    int n;
    cout<<"Enter Size of Array :"<<endl;
    cin>>n;
    int arr[n];
    cout<<"\nEnter Array Elements : ";
    for (int i = 0; i < n; i++){
        cin>>arr[i];
    }
    cout<<"\nThis is your simple Array : "<<endl;
    for(int i = 0; i <n;i++){
        cout<<arr[i]<<" ";
    }
    bubbleSort(arr,n);
    cout<<"\nAfete The Bubble Sort: "<<endl;
    for(int i = 0; i <n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;

}