# // #include<bits/stdc++.h>
# // using namespace std;


# // class Solution{

# // public :
# // int findmax(vector<int>&nums){
# //     int cnt = 0;
# //     int maxi = 0;
# //     for (int i=0;i<nums.size();i++){
# //         if (nums[i] == 1){
# //             cnt++;
# //         }
# //         else{
# //             cnt = 0;
# //         }
# //         maxi = max(maxi,cnt);
# //     }
# //     return maxi;
# // }

# // };

# // int main(){
# //     vector<int>nums = {1,1,0,1,1,1,1,1,1,1,1};
# //     Solution obj;
# //     int ans= obj.findmax(nums);
# //     cout<<"The maximum Consecutive 1's are :"<<ans;
# //     return 0;
# // }


# In python

from typing import List

class Solution:
    def findmax(self,nums:List[int]) -> int:
        cnt = 0
        maxi = 0
        for i in range(len(nums)):
            if nums[i] == 1:
                cnt += 1

            else:
                cnt = 0

            maxi =max(maxi,cnt)

        return maxi
    
if __name__ == "__main__":
    nums = [1,1,1,1,0,0,0]
    obj = Solution()
    ans = obj.findmax(nums)
    print("The Maximmum ConseCutive are :" , ans)