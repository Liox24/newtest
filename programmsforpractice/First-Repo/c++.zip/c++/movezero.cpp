#include <bits/stdc++.h>
using namespace std;
vector<int>zeroend(vector<int>arr,int n){
    vector<int>temp;
    for (int i=0;i<n;i++){
        if (arr[i] != 0)
        temp.push_back(arr[i]);
    }
    int nz = temp.size();
    for (int i=0;i<nz;i++){
        arr[i] = temp[i];
    }
     for (int i = nz; i < n; i++) {
        arr[i] = 0;
    }
    return arr;
}
int main()
{
    vector<int>v = {1,4,5,6,7,0,54,44,0,87,0,98,0,96,112,0,0,0,45};

    int siz = v.size();
    auto start = std::chrono::high_resolution_clock::now();
    vector<int>arr=zeroend(v,siz);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;

    double duration_ms = duration.count() * 1000;
    std::cout << "\nExecution time: " << duration_ms << " milliseconds" << std::endl;

    for (auto &it : arr){
        cout<<it<<" ";
    }
    return 0;
}