#include <bits/stdc++.h>
using namespace std;

void rotation(int arr[], int n, int k)
{
    if (n == 0)
        return;

    k = k % n;
    if (k > n)
    {
        return;
    }

    int temp[k];

    for (int i = n - k; i < n; i++)
    {
        temp[i - n + k] = arr[i];
    }
    for (int i = n - k - 1; i >= 0; i--)
    {
        temp[i + k] = arr[i];
    }

    for (int i = 0; i < n; i++)
    {
        arr[i] = temp[i];
    }
}

int main()
{
    int n;
    cout << "Enter the size of the array :";
    cin >> n;
    int array[n];
    for (int i = 0; i < n; i++)
    {
        cout << "Eneter " << i << " Index :";
        cin >> array[i];
    }
    int k;
    cout << "Enter the rotation number :";
    cin >> k;
    cout << "\nThis is Your Before Rotate array :";
    for (int i = 0; i < n; i++)
    {
        cout << array[i] << " ";
    }
    auto start = std::chrono::high_resolution_clock::now();
    rotation(array, n, k);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;

    double duration_ms = duration.count() * 1000;
    std::cout << "Execution time: " << duration_ms << " milliseconds" << std::endl;

    cout << "\nThis is Your Rotate array :";
    for (int i = 0; i < n; i++)
    {
        cout << array[i] << " ";
    }
    return 0;
}