#include<bits/stdc++.h>
using namespace std;



int main(){
    set<int>p;
    int n,o;
    cin>>n;
    cout<<"Enter Numbers : "<<endl;
    for (int i=0;i<n;i++){
        cin>>o;
        p.insert(o);
    }
    cout<<"This is Your Answer :";
    for (auto l : p){
        cout<<l<<" ";
    }   
    return 0;
}