#include <bits/stdc++.h>
using namespace std;

// A utility function to perform a single pass of Bubble Sort
// This function recursively calls itself until the entire array is sorted
void bubbleSortRecursive(int arr[], int n) {
    // Base case: If no elements are swapped in this pass, the array is sorted
    bool swapped = false;

    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            swap(arr[i], arr[i + 1]);
            swapped = true;
        }
    }

    // If no two elements were swapped in this pass, the array is sorted
    if (!swapped) {
        return;
    }

    // Otherwise, continue sorting the remaining elements
    bubbleSortRecursive(arr, n - 1);
}

int main() {
    int arr[] = {64, 34, 25, 12, 22, 11, 90};
    int n = sizeof(arr) / sizeof(arr[0]);

    std::cout << "Original Array: ";
    for (int i = 0; i < n; i++) {
        std::cout << arr[i] << " ";
    }

    bubbleSortRecursive(arr, n);

    std::cout << "\nSorted Array: ";
    for (int i = 0; i < n; i++) {
        std::cout << arr[i] << " ";
    }
    // cout<<"Size of Array = "<<sizeof(arr)<<endl;
    // cout<<"Size of Array = "<<sizeof(arr[0])<<endl;

    return 0;
}
