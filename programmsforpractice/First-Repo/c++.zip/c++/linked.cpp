#include<bits/stdc++.h>
using namespace std;

class node{
    public:
    int data;
    node *next;

    node(int data){
        this->data = data;
        this->next = NULL;
    }
};

class linkedlist{
    private:
    node *head;
    public :
    linkedlist(){
        head = NULL;
    }
    void insertatbeg(int data){
        node* newnode = new node(data);
        newnode->next = head;
        head = newnode;
    }
    void insertatend(int data){
        node* newnode = new node(data);
        if (head == NULL){
            head = newnode;
            return;
        }
        node* current  = head;
        while(current->next!=NULL){
            current = current->next;
        }
        current->next = newnode;
    }


    void deleteatposition(int position){
        if (head == NULL) {
            cout << "List is empty" << endl;
            return;
        }

        if (position == 0){
            node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        node *current = head;
        int count = 0;
        while(count < position -1 && current->next != NULL){
            current = current->next;
            count++;
        }

        node *temp = current->next;
        current->next = current->next->next;
        delete temp;
    }
    void insertatposition(int data,int pos){
        if (pos < 0){
            cout<<"Invalid Position"<<endl;
            return;
        }
        if(pos == 0){
            insertatbeg(data);
            return;
        }
        node *newnode = new node(data);
        node* current = head;
        int count = 0;
        while(count < pos - 1 && current != NULL){
            current = current->next;
            count++;
        }
        if (current == NULL){
            cout<<"Position out of range"<<endl;
            return;
        }
        newnode->next = current->next;
        current->next = newnode;
    }

    void display(){
        node *current = head;
        while(current != NULL){
            cout<<current->data<<" ->";
            current = current->next;
        }

        if (head == NULL){
            cout<<"\nNot Available...."<<endl;
        }
    }

    void rev(){
        node *prev = NULL;
        node *curr = head;
        while(curr != NULL){
            node *nextnode = curr->next;
            curr->next = prev;
            prev = curr;
            curr = nextnode;
        }
        head = prev;
    }
};

int main(){

    linkedlist linkedlist;
    while(true){
        cout << "\nMenu:" << endl;
        cout << "1. Insert at the beginning" << endl;
        cout << "2. Insert at the end" << endl;
        cout << "3. Insert at a given position" << endl;
        // cout << "4. Delete at a given position" << endl;
        // cout << "5. Delete at the first" << endl;
        // cout << "6. Delete at the last" << endl;
        cout << "7. Display" << endl;
        // cout << "8. Size of the linked list" << endl;
        cout << "9. Reverse the linked list" << endl;
        cout << "10. Exit" << endl;

        int choice;
        cin >> choice;

        int data, position;

        switch(choice){
            case 1:
                cout << "Enter data: ";
                cin >> data;
                linkedlist.insertatbeg(data);
                break;
            case 2: 
                cout<<"Enter Data : ";
                cin>>data;
                linkedlist.insertatend(data);
                break;

            case 3:
                cout<<"Enter data : ";
                cin>>data;
                cout<<"Enter Position :";
                cin>>position;
                linkedlist.insertatposition(data,position-1);
                break;

            case 9:
            linkedlist.rev();
            cout<<"\n\t\t\t This is Your Data ......\n";
            linkedlist.display();
            break;


            case 7:
                cout<<"\n\t\t\t This is Your Data ......\n";
                linkedlist.display();
                break; 

            case 10:
            return 0;
            default : 
            cout<<" Invalid Choice. please try Again."<<endl;
        }
    }
    return 0;
}