// #include<bits/stdc++.h>
// using namespace std;


// int getSingle(vector<int>arr){
//     int n = arr.size();
//     for (int i=0;i<n;i++){
//         int num = arr[i];
//         int cnt = 0;
//     }
    
// }
// int main(){
//     vector<int>arr =  {4,1,2,1,2};
//     int ans = getSingle(arr);
//     cout<<"The Single Element : "<<ans<<endl;
//     return 0;
// }


// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     vector<int>s = {1, 2, 3, 3, 3, 4, 4, 5, 6};
//     unordered_map<int,int>countmap;
//     for (int num : s){
//         countmap[num]++;
//     }
//     for (const auto &pair  : countmap){
//         cout<<pair.first<<" is "<<pair.second<< " Time";
//         if (pair.second > 1){
//             cout<<"'s";
//         }
//         cout<<endl;
//     }

//     return 0;
// }

// Which number is Single

#include<bits/stdc++.h>
using namespace std;

int getSingleElement(vector<int>v){
     unordered_map<int,int>countmap;
      for (int num : v){
        countmap[num]++;
    }
    for (const auto &pair  : countmap){
        if (pair.second == 1){
            return pair.first;
        }
    }
}

int main(){
    vector<int> arr = {4,4,3, 1, 2, 1, 2};
    int ans = getSingleElement(arr);
    cout << "The single element is: " << ans << endl;
    return 0;
}
