// #include<bits/stdc++.h>
// using namespace std;
void selectionSort(int arr[], int n) {
    for (int i = 0; i < 5 - 1; i++) {
        // Find the minimum element in the unsorted portion of the array
        int minIndex = i;
        for (int j = i + 1; j < 5; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }

        // 65 25 12 22 11 
        // 0  1  2  3   4
        // 11 25 12 22 65 
        // Swap the found minimum element with the element at position i
        int temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

// int main() {
//     int arr[] = {64, 25, 12, 22, 11};
//     int n = sizeof(arr) / sizeof(arr[0]);

//     std::cout << "Original array: ";
//     for (int i = 0; i < n; i++) {
//         std::cout << arr[i] << " ";
//     }

//     selectionSort(arr, n);

//     std::cout << "\nSorted array: ";
//     for (int i = 0; i < n; i++) {
//         std::cout << arr[i] << " ";
//     }

//     return 0;
// }



#include<bits/stdc++.h>
using namespace std;
// void selection_sort(int n,int arr[]){
//     int i;
//     for (int i=0;i<n-1;i++){
//         int minindex = i;

//         for (int j=i+1;i<n;j++){
//             if (arr[j] < arr[minindex]){
//                 minindex = j;
//             }
//         }

//         int temp = arr[i];
//         arr[i] = arr[minindex];
//         arr[minindex] = temp;
//     }
// }
int main(){    
    int n;
    cout<<"Enter Size of Array :"<<endl;
    cin>>n;
    int arr[n];
    cout<<"\nEnter Array Elements : ";
    for (int i = 0; i < n; i++){
        cin>>arr[i];
    }
    cout<<"\nThis is your simple Array : "<<endl;
    for(int i = 0; i <n;i++){
        cout<<arr[i]<<" ";
    }
    selectionSort(arr,n);
    cout<<"\nAfter Sorting : "<<endl;
    for(int i = 0; i <n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;
}